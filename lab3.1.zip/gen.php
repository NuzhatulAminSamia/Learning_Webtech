<?php

if (isset($_POST['submit'])) {
    $gen = $_POST['gen'];
    echo $gen;
}
?>


<html>
<body>
    <form method="POST">
        <fieldset>
            <legend>gen</legend>
            male <input type="radio" name="gen" value="male" />
            female <input type="radio" name="gen" value="female" />
            other <input type="radio" name="gen" value="other" />

    
            <hr>
            <input type="submit" name="submit" value="Submit" />
        </fieldset>
    </form>
</body>

</html>