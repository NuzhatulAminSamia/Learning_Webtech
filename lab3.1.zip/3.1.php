<?php 

    if(isset($_POST['submit'])){

        $name = $_POST['name'];
        

        if($name == "" ){
            echo "null username";
        }
        else {
        //    header('location:3.1.php');
        }
    }
?>
<html>

<body>
    <div>
        <form method="post">
            <fieldset>
                <legend>Name</legend>
                name: <input type="text" name="name" value="" /> <br>  
                <hr>      
                <input type="submit" name="submit" value="Submit" />
            </fieldset>
        </form>
    </div>
</body>
</html>