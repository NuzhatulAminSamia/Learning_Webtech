<?php

if (isset($_POST['submit'])) {
    $dob = $_POST['dob'];
    echo $dob;
}
?>


<html>
<body>
    <form method="post">
        <fieldset>
            <legend>dob</legend>
            dob : <input type="date" name="dob" value="" />
    
            <hr>
            <input type="submit" name="submit" value="Submit" />
        </fieldset>
    </form>
</body>

</html>