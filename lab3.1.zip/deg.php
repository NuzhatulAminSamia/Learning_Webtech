<?php

if (isset($_POST['submit'])) {
    $deg = $_POST['deg'];
    echo $deg;
}
?>


<html>
<body>
    <form method="POST">
        <fieldset>
            <legend>deg</legend>
             <input type="checkbox" name="deg" value="SSC" />SSC
            <input type="checkbox" name="deg" value="HSC" />HSC 
            <input type="checkbox" name="deg" value="BSc" />BSc
            <input type="checkbox" name="deg" value="MSc" />MSc 

    
            <hr>
            <input type="submit" name="submit" value="Submit" />
        </fieldset>
    </form>
</body>

</html>